// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/
 
// Import React and Component
import React, { useState } from 'react';
import {View, Text, SafeAreaView, StyleSheet} from 'react-native';
import {
    LineChart,
    BarChart,
    PieChart,
    ProgressChart,
    ContributionGraph,
    StackedBarChart, 
  } from 'react-native-chart-kit'
  import { Dimensions } from 'react-native';
  import AsyncStorage from '@react-native-async-storage/async-storage'
  import { ProgressBar} from 'react-native-paper';

  
const StatsScreen = () => {

    const [userName, setUserName] = useState('');
    const progress_number = 0.7;
    AsyncStorage.getItem("user_name").then((value) => {
      setUserName(value);
    });

    const linedata = {
        labels: ['M', 'T', 'W', 'T', 'F', 'S', 'S'],
        datasets: [
          {
            data: [40, 20, 60, 80,60],
            strokeWidth: 2, // optional
          },
        ],
      };
    
      function* yLabel() {
        yield* ['Very Low', 'Low', 'Ok', 'Good','Better'];
      }
      const yLabelIterator = yLabel();

  return (
    <SafeAreaView style={{flex: 1}}>
      <View style={{flex: 1, padding: 16}}>
        <View
          style={{
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
          }}>

<ProgressBar style={{ marginTop:50,height: 10, width:300}} progress={progress_number} color="#43C6DB" />

          <Text
            style={{
              fontSize: 20,
              textAlign: 'center',
              marginBottom: 16,
            }}>
            You have completed x out of 20 sessions.
          </Text>
        </View>
        <View>
          <Text style={{
              fontSize: 20,
              marginBottom: 16,
            }}>
           Your Weekly Mood Chart
          </Text>
          <LineChart
            data={linedata}
            width={Dimensions.get('window').width-30} // from react-native
            height={250}
            formatYLabel={() => yLabelIterator.next().value}
            //yAxisLabel={''}
            chartConfig={{
              backgroundColor: '#e26a00',
              backgroundGradientFrom: '#fb8c00',
              backgroundGradientTo: '#ffa726',
              decimalPlaces: 0, // optional, defaults to 2dp
              color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
              style: {
                borderRadius: 16
              }
            }}
            
            style={{
              marginVertical: 8,
              borderRadius: 16
            }}
            >
            
          </LineChart>
        </View>
      </View>
    </SafeAreaView>
  );
};
 
export default StatsScreen;

const styles = StyleSheet.create({
progressBar: {
   height: 20,
   flexDirection: "row",
   width: '100%',
   backgroundColor: 'white',
   borderColor: '#000',
   borderWidth: 2,
   borderRadius: 5
 }
});