// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, { useState } from 'react';
import { View, Text, SafeAreaView, LogBox, StyleSheet, TouchableOpacity, Button } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage'

import YoutubePlayer from 'react-native-youtube-iframe';
import { WebView } from 'react-native-webview';
import Swiper from "react-native-deck-swiper";

const HomeScreen = () => {
  // Ignore log notification by message
  LogBox.ignoreLogs(['Warning: ...']);

  //Ignore all log notifications
  LogBox.ignoreAllLogs();

  const handleSubmitPress = () => {
    alert('next action');
    return;
  }

  const [userName, setUserName] = useState('');
  const [cards, setCards] = useState('');
  AsyncStorage.getItem("user_name").then((value) => {
    setUserName(value);
  });

  return (

    <SafeAreaView style={{ flex: 1 }}>
      <View style={{ flex: 1, padding: 20 }}>
        <View
          >
          <Text
            style={{
              fontSize: 20,
              textAlign: 'center',
              paddingBottom: 10
            }}>
            Welcome, {userName}
          </Text>
        </View>

        <TouchableOpacity
          style={styles.buttonStyle}
          activeOpacity={0.5}
          onPress={handleSubmitPress}>
          <Text style={styles.buttonTextStyle}>How are you today?</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.buttonStyle}
          activeOpacity={0.5}
          onPress={handleSubmitPress}>
          <Text style={styles.buttonTextStyle}>Quick reads</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.buttonStyle}
          activeOpacity={0.5}
          onPress={handleSubmitPress}>
          <Text style={styles.buttonTextStyle}>Start/Resume Sessions</Text>
        </TouchableOpacity>
        <View style={{ flex: 1, alignItems: 'center', padding: 20 }}>
          <Text
            style={{
              fontSize: 20,
              marginBottom: 16,
            }}>
            Meditation for everyday..
          </Text>
          <YoutubePlayer
            height={350}
            width={350}
            play={false}
            videoId={'inpok4MKVLM'}
          />
      </View>
      </View>
    </SafeAreaView>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({

  buttonStyle: {
    backgroundColor: '#43C6DB',
    borderWidth: 0,
    color: '#FFFFFF',
    borderColor: '#7DE24E',
    height: 40,
    alignItems: 'center',
    borderRadius: 30,
    marginLeft: 35,
    marginRight: 35,
    marginTop: 20,
    marginBottom: 25,
  },
  buttonTextStyle: {
    color: '#FFFFFF',
    paddingVertical: 10,
    fontSize: 16,
  },

 
    card_container: {
      height: 50,
      backgroundColor: "#F5FCFF"
    },

    text: {
      textAlign: "center",
      fontSize: 50,
      backgroundColor: "transparent"
    }

});